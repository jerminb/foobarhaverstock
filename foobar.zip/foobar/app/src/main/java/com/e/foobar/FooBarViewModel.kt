package com.e.foobar

import android.util.Log
import androidx.lifecycle.ViewModel

class FooBarViewModel: ViewModel() {
    private var playsList: MutableList<Play> = mutableListOf()
    private lateinit var currentPlay: Play

    init {
        Log.d("MainActivity", "FooBarViewModel created!")
        getNextPlay()
    }

    override fun onCleared() {
        super.onCleared()
        Log.d("MainActivity", "FooBarViewModel destroyed!")
    }
    fun resetPlay() {
        playsList = mutableListOf()
        getNextPlay()
    }
    private fun getNextPlay() {
        currentPlay = Play(0,0,0, 0)
        playsList.add(currentPlay)
    }

    var currentPlayPasses: Int
        get() = currentPlay.passes
        set(value) {currentPlay.passes = value}

    var currentPlayCrosses: Int
        get() = currentPlay.crosses
        set(value) {currentPlay.crosses = value}

    var currentPlayCarries: Int
        get() = currentPlay.carries
        set(value) {currentPlay.carries = value}

    var currentPlayShots: Int
        get() = currentPlay.shots
        set(value) {currentPlay.shots = value}

    fun incrementCurrentPlay(action: PlayAction) {
        when(action){
            PlayAction.PASS -> ++currentPlay.passes
            PlayAction.CARRY -> ++currentPlay.carries
            PlayAction.CROSS -> ++currentPlay.crosses
            PlayAction.SHOT -> ++currentPlay.shots
        }
    }
}