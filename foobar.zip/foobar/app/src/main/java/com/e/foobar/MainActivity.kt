package com.e.foobar

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import androidx.databinding.DataBindingUtil
import com.e.foobar.databinding.ActivityMainBinding


private const val DEBUG_TAG = "Gestures"

class MainActivity : AppCompatActivity() {
    private lateinit var mDetector: GestureDetectorCompat
    private val viewModel: FooBarViewModel by viewModels()
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        binding.txtCrosses.text = viewModel.currentPlayCrosses.toString()

        // Instantiate the gesture detector with the
        // application context and an implementation of
        // GestureDetector.OnGestureListener
        mDetector = GestureDetectorCompat(this, GestureListenerDelegate(this, viewModel, binding))
        setContentView(binding.root)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        mDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    private class GestureListenerDelegate(val context: Context, val viewModel: FooBarViewModel, val binding: ActivityMainBinding) : GestureDetector.SimpleOnGestureListener() {
        private fun setViewBinding(){
            binding.txtPasses.text = viewModel.currentPlayPasses.toString()
            binding.txtCarries.text = viewModel.currentPlayCarries.toString()
            binding.txtCrosses.text = viewModel.currentPlayCrosses.toString()
            binding.txtShots.text = viewModel.currentPlayShots.toString()
        }
        private fun displayToast(action: PlayAction){
            val toast = Toast(this.context)
            val view = ImageView(this.context)
            when(action){
                PlayAction.PASS -> view.setImageResource(R.drawable.fb_pass)
                PlayAction.CARRY -> view.setImageResource(R.drawable.fb_carry)
                PlayAction.CROSS -> view.setImageResource(R.drawable.fb_long_ball)
                PlayAction.SHOT -> view.setImageResource(R.drawable.fb_shot)
            }
            toast.setView(view)
            toast.show()
        }
        private fun incrementCurrentPlay(action: PlayAction){
            viewModel.incrementCurrentPlay(action)
            setViewBinding()
        }
        override fun onDoubleTap(event: MotionEvent): Boolean {
            displayToast(PlayAction.SHOT)
            incrementCurrentPlay(PlayAction.SHOT)
            return true
        }

        override fun onSingleTapConfirmed(event: MotionEvent): Boolean {
            displayToast(PlayAction.PASS)
            incrementCurrentPlay(PlayAction.PASS)
            return true
        }

        override fun onLongPress(event: MotionEvent) {
            displayToast(PlayAction.CROSS)
            incrementCurrentPlay(PlayAction.CROSS)
        }

        /*override fun onScroll(
            event1: MotionEvent,
            event2: MotionEvent,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            Log.d(DEBUG_TAG, "onScroll: $event1 $event2")
            return true
        }*/

        override fun onFling(
            event1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            Log.d(DEBUG_TAG, "onFling: $event1")
            return true
        }
    }
}