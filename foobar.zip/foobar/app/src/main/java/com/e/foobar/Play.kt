package com.e.foobar

data class Play (
    var passes: Int,
    var shots: Int,
    var carries: Int,
    var crosses: Int
)