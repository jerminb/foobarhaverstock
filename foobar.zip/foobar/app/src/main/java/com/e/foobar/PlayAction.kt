package com.e.foobar

enum class PlayAction {
    PASS,
    CROSS,
    SHOT,
    CARRY
}